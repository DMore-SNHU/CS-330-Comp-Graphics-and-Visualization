///////////////////////////////////////////////////////////////////////////////
// SceneManager.h
// ============
// Declares the functions and variables used to prepare
// and render the Alchemy Table 3D scene.
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
// 
//  EDITED BY: David Morelli - SNHU Student
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"

#include <string>
#include <vector>

/***********************************************************
 * SceneManager
 *
 * Manages the textures, materials, lighting, and rendering
 * of the objects in the Alchemy Table 3D scene.
 ***********************************************************/
class SceneManager
{
public:
	// constructor
	SceneManager(ShaderManager *pShaderManager);
	// destructor
	~SceneManager();

	struct TEXTURE_INFO
	{
		std::string tag;
		uint32_t ID;
	};

	struct OBJECT_MATERIAL
	{
		float ambientStrength;
		glm::vec3 ambientColor;
		glm::vec3 diffuseColor;
		glm::vec3 specularColor;
		float shininess;
		std::string tag;
	};

private:
	// pointer to shader manager object
	ShaderManager* m_pShaderManager;
	// pointer to basic shapes object
	ShapeMeshes* m_basicMeshes;
	// total number of loaded textures
	int m_loadedTextures;
	// Store the texture IDs and tags for up to 50 loaded textures.
	TEXTURE_INFO m_textureIDs[50];
	// defined object materials
	std::vector<OBJECT_MATERIAL> m_objectMaterials;
	// Custom half-cylinder mesh for rounded book spines.
	GLuint m_bookSpineVAO = 0;
	GLuint m_bookSpineVBO = 0;
	GLuint m_bookSpineEBO = 0;
	GLsizei m_bookSpineIndexCount = 0;

	// OpenGL buffers for the custom hexagonal crystal.
	GLuint m_hexCrystalVAO = 0;
	GLuint m_hexCrystalVBO = 0;

	// Number of vertices used to draw the crystal.
	GLsizei m_hexCrystalVertexCount = 0;

	// OpenGL buffers for the rocky base
	GLuint m_rockBaseVAO = 0;
	GLuint m_rockBaseVBO = 0;

	// Number of vertices in the rocky base
	GLsizei m_rockBaseVertexCount = 0;

	// Rounded chest lid mesh
	GLuint m_chestLidVAO = 0;
	GLuint m_chestLidVBO = 0;

	// Number of vertices in the chest lid
	GLsizei m_chestLidVertexCount = 0;

	// load texture images and convert to OpenGL texture data
	bool CreateGLTexture(const char* filename, std::string tag);
	// bind loaded OpenGL textures to slots in memory
	void BindGLTextures();
	// free the loaded OpenGL textures
	void DestroyGLTextures();
	// Find a loaded texture ID using its tag.
	int FindTextureID(std::string tag);
	// Find the texture slot associated with a tag.
	int FindTextureSlot(std::string tag);
	// find a defined material by tag
	bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);

	// set the transformation values 
	// into the transform buffer
	void SetTransformations(
		glm::vec3 scaleXYZ,
		float XrotationDegrees,
		float YrotationDegrees,
		float ZrotationDegrees,
		glm::vec3 positionXYZ);

	// set the color values into the shader
	void SetShaderColor(
		float redColorValue,
		float greenColorValue,
		float blueColorValue,
		float alphaValue);

	// set the texture data into the shader
	void SetShaderTexture(
		std::string textureTag);

	// set the UV scale for the texture mapping
	void SetTextureUVScale(
		float u, float v);

	// set the object material into the shader
	void SetShaderMaterial(
		std::string materialTag);
	
	// Set the alpha value used to control object transparency.
	void SetShaderAlpha(float alpha);

	// Create the custom rounded book spine mesh.
	void CreateBookSpineMesh();

	// Render the book spine using the selected leather and title textures.
	void DrawBookSpineMesh(
		std::string leatherTexture,
		std::string spineTexture);

	glm::mat4 m_bookTransform = glm::mat4(1.0f);
	bool m_useBookTransform = false;

public:

	// The following methods are for the students to
	// customize for their own 3D scene

	// Define materials used for lighting calculations
	void DefineObjectMaterials();

	// Configure the lighting for the 3D scene
	void SetupSceneLights();

	// Prepare and render the scene
	void PrepareScene();
	void RenderScene();
	void RenderTable();
	void RenderPotionBottle();
	void RenderSingleBook(
		float bookHeight,
		std::string leatherTexture,
		std::string spineTexture,
		std::string coverTexture);

	// Render the large Arcane Grimoire spellbook.
	void RenderSpellbook();

	// Render the crystal cluster and its rocky base.
	void RenderCrystal();
	// Create the custom six-sided crystal mesh.
	void CreateHexCrystalMesh();
	// Draw the custom crystal mesh.
	void DrawHexCrystalMesh();

	// Render the alchemist's storage chest.
	void RenderAlchemyChest();
	// Create the rounded alchemy chest lid
	void CreateChestLidMesh();
	// Draw the curved top of the lid
	void DrawChestLidTop();
	// Draw the rounded ends and underside
	void DrawChestLidSides();

	// Create the custom jagged rocky base mesh.
	void CreateRockBaseMesh();
	// Draw the rocky base beneath the crystal cluster.
	void DrawRockBaseMesh();

};