///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// ================
// Manages the textures, materials, lighting, and rendering
// of the Alchemy Table 3D scene.
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
// 
//	EDITED BY: David Morelli - SNHU Student
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
	const char* g_AlphaValueName = "objectAlpha";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// Initialize the number of loaded textures.
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// Allow RGB textures with widths not divisible by 4.
		glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// Generate mipmaps for displaying textures at smaller resolutions.
		glGenerateMipmap(GL_TEXTURE_2D);


		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture


		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 * BindGLTextures()
 *
 * Binds the loaded textures to their corresponding OpenGL
 * texture units for use when rendering the 3D scene.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	GLint maxTextureUnits = 0;

	glGetIntegerv(
		GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS,
		&maxTextureUnits);

	std::cout << "Maximum texture units: "
		<< maxTextureUnits << std::endl;

	std::cout << "Loaded textures: "
		<< m_loadedTextures << std::endl;

	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 * DestroyGLTextures()
 *
 * Deletes the loaded OpenGL textures and releases
 * their associated graphics memory.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(bFound);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (m_useBookTransform)
	{
		modelView = m_bookTransform * modelView;
	}

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/***********************************************************
 * SetShaderAlpha()
 *
 * Sets the alpha value used to control object transparency
 * when rendering the Alchemy Table scene.
 ***********************************************************/
void SceneManager::SetShaderAlpha(float alpha)
{
	if (m_pShaderManager != NULL)
	{
		m_pShaderManager->setFloatValue(g_AlphaValueName, alpha);
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 * PrepareScene()
 *
 * Loads the textures, prepares the 3D meshes, and sets up
 * the materials and lighting for the Alchemy Table scene.
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// Load texture for the cork stopper.
	CreateGLTexture("textures/cork.jpg", "cork");

	// Load texture for the liquid in bottle.
	CreateGLTexture("textures/potion.jpg", "potion");

	// Load texture for the rim, upper neck, and base.
	CreateGLTexture("textures/glass.jpg", "glass");

	// Load texture for the table/ground.
	CreateGLTexture("textures/wood_table.png", "woodTable");

	// Load the texture of the spine that says "ALCHEMY". 
	CreateGLTexture("textures/alchemy_title.png", "alchemyTitle");
	// Load the texture of the spine that says "POTIONS".
	CreateGLTexture("textures/potions_title.png", "potionsTitle");
	// Load the texture of the spine that says "HERBOLOGY".
	CreateGLTexture("textures/herb_title.png", "herbTitle");

	// Decorative leather texture for the alchemy book cover.
	CreateGLTexture("textures/alchemy_cover.png", "alchemyCover");
	// Decorative leather texture for the potions book cover.
	CreateGLTexture("textures/potions_cover.png", "potionsCover");
	// Decorative leather texture for the herbology book cover.
	CreateGLTexture("textures/herbology_cover.png", "herbologyCover");

	// Loads just the red leather texture.
	CreateGLTexture("textures/red_leather.png", "redLeather");
	// Loads just the purple leather texture.
	CreateGLTexture("textures/purple_leather.png", "purpleLeather");
	// Loads just the green leather texture.
	CreateGLTexture("textures/green_leather.png", "greenLeather");

	// Large Arcane Grimoire cover texture.
	CreateGLTexture("textures/grimoire_cover.png", "grimoireCover");
	// Load the brown leather texture for the Arcane Grimoire.
	CreateGLTexture("textures/brown_leather.png", "brownLeather");
	// Loads just the texture for the spine of the Grimoire.
	CreateGLTexture("textures/grimoire_spine.png", "grimoireSpine");

	// Loads the texture for the pages of the books.
	CreateGLTexture("textures/pages.png", "pages");

	// Loads the texture for the orange crystal.
	CreateGLTexture("textures/orange_quartz.png", "orangeQuartz");
	// Loads the texture for the red crystal.
	CreateGLTexture("textures/red_quartz.png", "redQuartz");
	// Loads the texture for the yellow crystal.
	CreateGLTexture("textures/yellow_quartz.png", "yellowQuartz");
	// Load the dark rock texture for the crystal cluster's base.
	CreateGLTexture("textures/dark_rock.png", "darkRock");

	// Alchemy chest textures
	CreateGLTexture("textures/chest_front.png", "chestFront");
	CreateGLTexture("textures/chest_back.png", "chestBack");
	CreateGLTexture("textures/chest_side.png", "chestSide");
	CreateGLTexture("textures/chest_wood.png", "chestWood");
	CreateGLTexture("textures/chest_lid.png", "chestLid");

	// Bind the loaded textures to OpenGL.
	BindGLTextures();

	// Load the basic 3D meshes used throughout the Alchemy Table scene.
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadPrismMesh();

	// Create the custom rounded book spine mesh.
	CreateBookSpineMesh();
	// Create the custom six-sided crystal mesh.
	CreateHexCrystalMesh();
	// Create the custom jagged rocky base mesh.
	CreateRockBaseMesh();
	// Create the rounded alchemy chest lid mesh.
	CreateChestLidMesh();

	// Define the materials for our objects.
	DefineObjectMaterials();

	// Configure the scene lighting.
	SetupSceneLights();
}

/***********************************************************
 * RenderTable()
 *
 * Renders the wooden table for the Alchemy scene.
 ***********************************************************/
void SceneManager::RenderTable()
{
	// Declare the variables used to position, rotate, and scale the table.
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;

	// --------------------------------------------------
	// Wooden tabletop that serves as the base for the alchemy scene.
	// --------------------------------------------------
	scaleXYZ = glm::vec3(10.0f, 1.0f, 5.0f);
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Sets the shader and shader scale for the table/ground.
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("woodTable");
	SetShaderMaterial("wood");

	m_basicMeshes->DrawPlaneMesh();
}

/***********************************************************
 * RenderPotionBottle()
 *
 * Renders the potion bottle, including the liquid,
 * cork stopper, glass neck, rim, and transparent shell.
 ***********************************************************/
void SceneManager::RenderPotionBottle()
{
	// Declare transformation variables.
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	// Controls the position of the entire potion bottle.
	glm::vec3 bottleOffset = glm::vec3(-3.0f, 0.0f, -2.0f);

	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;

	// --------------------------------------------------
	// Potion bottle - rounded blue body
	// --------------------------------------------------
	scaleXYZ = glm::vec3(0.95f, 0.85f, 0.85f);
	positionXYZ = glm::vec3(0.0f, 0.85f, 0.0f) + bottleOffset;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Sets the shader and shader scale for the body of the potion bottle. 
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("potion");
	SetShaderMaterial("potion");

	m_basicMeshes->DrawSphereMesh();

	// --------------------------------------------------
	// Potion bottle - cork stopper
	// --------------------------------------------------
	scaleXYZ = glm::vec3(0.22f, 0.40f, 0.22f);
	positionXYZ = glm::vec3(0.0f, 2.12f, 0.0f) + bottleOffset;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);


	// Sets the shader and shader scale for the cork.
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("cork");
	SetShaderMaterial("cork");

	m_basicMeshes->DrawCylinderMesh();

	// --------------------------------------------------
	// Potion bottle - lower neck with potion
	// --------------------------------------------------
	scaleXYZ = glm::vec3(0.24f, 0.38f, 0.24f);
	positionXYZ = glm::vec3(0.0f, 1.55f, 0.0f) + bottleOffset;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Sets the shader and shader scale for the lower part of the bottle neck.
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("potion");
	SetShaderMaterial("potion");

	m_basicMeshes->DrawCylinderMesh();


	// --------------------------------------------------
	// Potion bottle - upper glass neck
	// --------------------------------------------------
	scaleXYZ = glm::vec3(0.24f, 0.32f, 0.24f);
	positionXYZ = glm::vec3(0.0f, 1.93f, 0.0f) + bottleOffset;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the glass material and low opacity to make the upper neck transparent while keeping the potion visible.
	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	SetShaderMaterial("glass");
	SetShaderAlpha(0.10f);

	glDepthMask(GL_FALSE);
	m_basicMeshes->DrawCylinderMesh();
	glDepthMask(GL_TRUE);

	SetShaderAlpha(1.0f);

	// --------------------------------------------------
	// Potion bottle - glass rim
	// --------------------------------------------------
	scaleXYZ = glm::vec3(0.30f, 0.10f, 0.30f);
	positionXYZ = glm::vec3(0.0f, 2.25f, 0.0f) + bottleOffset;

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	// Sets the shader and shader scale for the glass rim around the cork.
	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	SetShaderMaterial("glass");
	SetShaderAlpha(0.10f);

	glDepthMask(GL_FALSE);
	m_basicMeshes->DrawCylinderMesh();
	glDepthMask(GL_TRUE);

	SetShaderAlpha(1.0f);


	// --------------------------------------------------
	// Potion bottle - flat bottom
	// --------------------------------------------------
	scaleXYZ = glm::vec3(0.45f, 0.15f, 0.45f);
	positionXYZ = glm::vec3(0.0f, 0.02f, 0.0f) + bottleOffset;

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	// Sets the shader and shader scale for the bottom of the potion bottle.
	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	SetShaderMaterial("glass");
	SetShaderAlpha(0.10f);

	glDepthMask(GL_FALSE);
	m_basicMeshes->DrawCylinderMesh();
	glDepthMask(GL_TRUE);

	SetShaderAlpha(1.0f);

	// --------------------------------------------------
	// Potion bottle - transparent outer glass shell
	// --------------------------------------------------
	scaleXYZ = glm::vec3(1.02f, 0.92f, 0.92f);
	positionXYZ = glm::vec3(0.0f, 0.85f, 0.0f) + bottleOffset;

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	// Use a neutral glass color instead of a texture.
	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	SetShaderMaterial("glass");
	SetShaderAlpha(0.10f);

	// Prevent the transparent glass from writing to the depth buffer.
	glDepthMask(GL_FALSE);
	m_basicMeshes->DrawSphereMesh();
	glDepthMask(GL_TRUE);

	// Restore opacity for subsequent objects.
	SetShaderAlpha(1.0f);

	// --------------------------------------------------
	// Potion bottle - transparent glass neck
	// --------------------------------------------------
	scaleXYZ = glm::vec3(0.27f, 0.52f, 0.27f);
	positionXYZ = glm::vec3(0.0f, 1.73f, 0.0f) + bottleOffset;

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	// Transparent glass surrounding the bottle neck.
	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	SetShaderMaterial("glass");
	SetShaderAlpha(0.10f);

	// Render transparent glass without writing to depth buffer.
	glDepthMask(GL_FALSE);
	m_basicMeshes->DrawCylinderMesh();
	glDepthMask(GL_TRUE);

	// Reset opacity so the next objects render normally.
	SetShaderAlpha(1.0f);
}

/***********************************************************
 * CreateBookSpineMesh()
 *
 * Creates a custom half-cylinder mesh for rounded
 * leather book spines.
 ***********************************************************/
void SceneManager::CreateBookSpineMesh()
{
	// Number of segments used to create the rounded surface.
	const int segments = 24;

	// Dimensions of the half-cylinder.
	const float radius = 0.5f;
	const float length = 1.0f;

	// Store vertex data and triangle indices.
	std::vector<float> vertices;
	std::vector<unsigned int> indices;

	// Generate vertices along the curved half-cylinder.
	for (int i = 0; i <= segments; i++)
	{
		float angle = glm::pi<float>() * i / segments;

		float x = -radius * 0.40f * sin(angle);
		float y = radius * cos(angle);

		// Outward-facing normal for lighting.
		float normalX = -sin(angle);
		float normalY = cos(angle);

		// Front and back vertices along the Z-axis.
		for (int j = 0; j < 2; j++)
		{
			float z = (j == 0) ? -length / 2.0f : length / 2.0f;

			// Position (X, Y, Z)
			vertices.push_back(x);
			vertices.push_back(y);
			vertices.push_back(z);

			// Normal (X, Y, Z)
			vertices.push_back(normalX);
			vertices.push_back(normalY);
			vertices.push_back(0.0f);

			// Rotate the UV coordinates 90 degrees to align the book title texture correctly along the curved spine.
			float u = static_cast<float>(i) / segments;
			float v = static_cast<float>(j);

			vertices.push_back(v);
			vertices.push_back(1.0f - u);
		}
	}

	// --------------------------------------------------
	// Generate triangles for the curved surface.
	// --------------------------------------------------
	for (int i = 0; i < segments; i++)
	{
		unsigned int current = i * 2;
		unsigned int next = (i + 1) * 2;

		// First triangle
		indices.push_back(current);
		indices.push_back(next);
		indices.push_back(current + 1);

		// Second triangle
		indices.push_back(current + 1);
		indices.push_back(next);
		indices.push_back(next + 1);
	}

	// --------------------------------------------------
	// Close the flat back of the rounded book spine.
	// --------------------------------------------------

	// Connect the two ends of the semicircle.
	unsigned int topFront = 0;
	unsigned int topBack = 1;

	unsigned int bottomFront = segments * 2;
	unsigned int bottomBack = segments * 2 + 1;

	// First triangle of the flat back.
	indices.push_back(topFront);
	indices.push_back(topBack);
	indices.push_back(bottomFront);

	// Second triangle of the flat back.
	indices.push_back(bottomFront);
	indices.push_back(topBack);
	indices.push_back(bottomBack);

	// --------------------------------------------------
	// Close both ends of the rounded book spine.
	// --------------------------------------------------

	for (int i = 0; i < segments; i++)
	{
		unsigned int current = i * 2;
		unsigned int next = (i + 1) * 2;

		// Front end (negative Z)
		indices.push_back(0);
		indices.push_back(next);
		indices.push_back(current);

		// Back end (positive Z)
		indices.push_back(1);
		indices.push_back(current + 1);
		indices.push_back(next + 1);
	}

	// --------------------------------------------------
	// Create OpenGL buffers for the custom book spine.
	// --------------------------------------------------
	glGenVertexArrays(1, &m_bookSpineVAO);
	glGenBuffers(1, &m_bookSpineVBO);
	glGenBuffers(1, &m_bookSpineEBO);

	// Bind the Vertex Array Object.
	glBindVertexArray(m_bookSpineVAO);

	// Upload vertex data.
	glBindBuffer(GL_ARRAY_BUFFER, m_bookSpineVBO);
	glBufferData(
		GL_ARRAY_BUFFER,
		vertices.size() * sizeof(float),
		vertices.data(),
		GL_STATIC_DRAW
	);

	// Upload triangle indices.
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m_bookSpineEBO);
	glBufferData(
		GL_ELEMENT_ARRAY_BUFFER,
		indices.size() * sizeof(unsigned int),
		indices.data(),
		GL_STATIC_DRAW
	);

	// --------------------------------------------------
	// Configure vertex attributes.
	// --------------------------------------------------

	// Each vertex contains 8 floats:
	// Position (3), Normal (3), Texture coordinates (2).
	const GLsizei stride = 8 * sizeof(float);

	// Attribute 0: Vertex position.
	glVertexAttribPointer(
		0, 3, GL_FLOAT, GL_FALSE,
		stride, (void*)0
	);
	glEnableVertexAttribArray(0);

	// Attribute 1: Vertex normal.
	glVertexAttribPointer(
		1, 3, GL_FLOAT, GL_FALSE,
		stride, (void*)(3 * sizeof(float))
	);
	glEnableVertexAttribArray(1);

	// Attribute 2: Texture coordinates.
	glVertexAttribPointer(
		2, 2, GL_FLOAT, GL_FALSE,
		stride, (void*)(6 * sizeof(float))
	);
	glEnableVertexAttribArray(2);

	// Store the number of indices for drawing.
	m_bookSpineIndexCount = static_cast<GLsizei>(indices.size());

	// Unbind the VAO and vertex buffer.
	glBindVertexArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
}

/***********************************************************
 * DrawBookSpineMesh()
 *
 * Renders the custom half-cylinder book spine.
 ***********************************************************/
void SceneManager::DrawBookSpineMesh(
	std::string leatherTexture,
	std::string spineTexture)
{
	glBindVertexArray(m_bookSpineVAO);

	// -----------------------------------------
	// Apply the title texture to the curved outside of the book spine.
	// -----------------------------------------
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture(spineTexture);

	glDrawElements(
		GL_TRIANGLES,
		24 * 6,
		GL_UNSIGNED_INT,
		0
	);

	// -----------------------------------------
	// Apply the matching leather texture to the flat back and both ends.
	// -----------------------------------------
	SetTextureUVScale(0.25f, 0.25f);
	SetShaderTexture(leatherTexture);

	glDrawElements(
		GL_TRIANGLES,
		m_bookSpineIndexCount - (24 * 6),
		GL_UNSIGNED_INT,
		(void*)(24 * 6 * sizeof(unsigned int))
	);

	glBindVertexArray(0);
}

/***********************************************************
 * RenderSingleBook()
 *
 * Renders one book using the provided leather, spine,
 * and cover textures, along with its position in the stack.
 ***********************************************************/
void SceneManager::RenderSingleBook(
	float bookHeight,
	std::string leatherTexture,
	std::string spineTexture,
	std::string coverTexture)
{
	// Declare transformation variables.
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	// Controls the position of the entire book stack.
	glm::vec3 booksOffset = glm::vec3(-8.0f, 0.0f, -2.5f);

	// Vertical positions for the three books.
	float alchemyHeight = 0.0f;
	float potionsHeight = 0.64f;
	float herbologyHeight = 1.28f;

	float bookRotation = 245.0f;
	float bookScale = 2.0f;

	glm::mat4 bookTransform =
		glm::translate(
			glm::mat4(1.0f),
			booksOffset + glm::vec3(0.0f, bookHeight, 0.0f)) *
		glm::rotate(glm::mat4(1.0f),
			glm::radians(bookRotation),
			glm::vec3(0.0f, 1.0f, 0.0f)) *
		glm::scale(glm::mat4(1.0f),
			glm::vec3(bookScale, bookScale, bookScale));

	m_bookTransform = bookTransform;
	m_useBookTransform = true;

	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;

	// --------------------------------------------------
	// Alchemy book - bottom leather cover
	// --------------------------------------------------
	scaleXYZ = glm::vec3(1.8f, 0.04f, 1.2f);
	positionXYZ = glm::vec3(0.0f, 0.02f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the leather texture and material to the bottom book cover.
	SetShaderColor(0.35f, 0.08f, 0.10f, 1.0f);
	SetShaderTexture(leatherTexture);
	SetShaderMaterial("wood");
	SetShaderAlpha(1.0f);

	m_basicMeshes->DrawBoxMesh();


	// --------------------------------------------------
	// Alchemy book - top leather cover
	// --------------------------------------------------
	scaleXYZ = glm::vec3(1.8f, 0.04f, 1.2f);
	positionXYZ = glm::vec3(0.0f, 0.28f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Dark burgundy leather cover.
	SetShaderColor(0.35f, 0.08f, 0.10f, 1.0f);
	SetShaderTexture(leatherTexture);
	SetShaderMaterial("wood");
	SetShaderAlpha(1.0f);

	m_basicMeshes->DrawBoxMesh();

	// --------------------------------------------------
	// Alchemy book - decorative top cover surface
	// --------------------------------------------------
	scaleXYZ = glm::vec3(0.9f, 1.0f, 0.6f);
	positionXYZ = glm::vec3(0.0f, 0.301f, 0.0f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture(coverTexture);
	SetShaderMaterial("wood");
	SetShaderAlpha(1.0f);

	m_basicMeshes->DrawPlaneMesh();

	// --------------------------------------------------
	// Alchemy book - rounded leather spine
	// --------------------------------------------------
	scaleXYZ = glm::vec3(0.30f, 0.30f, 1.80f);
	positionXYZ = glm::vec3(0.0f, 0.15f, -0.60f);

	// Our custom mesh already runs along the Z-axis.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 270.0f;
	ZrotationDegrees = 0.0f;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Dark burgundy leather spine.
	SetShaderColor(0.35f, 0.08f, 0.10f, 1.0f);
	SetShaderMaterial("wood");
	SetShaderAlpha(1.0f);

	DrawBookSpineMesh(leatherTexture, spineTexture);

	// Reset rotation so other objects aren't affected.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// --------------------------------------------------
	// Alchemy book - cream-colored pages
	// --------------------------------------------------
	scaleXYZ = glm::vec3(1.75f, 0.22f, 1.15f);
	positionXYZ = glm::vec3(0.0f, 0.15f, -0.025f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Aged parchment color.
	SetShaderColor(0.85f, 0.78f, 0.60f, 1.0f);
	SetShaderTexture("pages");
	SetShaderMaterial("wood");
	SetShaderAlpha(1.0f);

	m_basicMeshes->DrawBoxMesh();	

	// Disable the shared book transformation
	m_useBookTransform = false;
}

/***********************************************************
 * RenderSpellbook()
 *
 * Renders the Spellbook in the middle of the scene.
 ***********************************************************/
void SceneManager::RenderSpellbook()
{
	// Declare transformation variables.
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	// Controls the position of the spellbook.
	glm::vec3 booksOffset = glm::vec3(0.0f, 0.0f, 2.0f);

	// Large spellbook settings.
	float bookHeight = 0.0f;
	float bookRotation = 90.0f;
	float bookScale = 3.0f;

	// Apply the selected textures to the Arcane Grimoire.
	std::string leatherTexture = "brownLeather";
	std::string spineTexture = "grimoireSpine";
	std::string coverTexture = "grimoireCover";

	glm::mat4 bookTransform =
		glm::translate(
			glm::mat4(1.0f),
			booksOffset + glm::vec3(0.0f, bookHeight, 0.0f)) *
		glm::rotate(glm::mat4(1.0f),
			glm::radians(bookRotation),
			glm::vec3(0.0f, 1.0f, 0.0f)) *
		glm::scale(glm::mat4(1.0f),
			glm::vec3(bookScale, bookScale, bookScale));

	m_bookTransform = bookTransform;
	m_useBookTransform = true;

	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;

	// --------------------------------------------------
	// Spellbook - bottom leather cover
	// --------------------------------------------------
	scaleXYZ = glm::vec3(1.8f, 0.04f, 1.2f);
	positionXYZ = glm::vec3(0.0f, 0.02f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the selected material and texture to the Arcane Grimoire.
	SetShaderColor(0.35f, 0.08f, 0.10f, 1.0f);
	SetShaderTexture(leatherTexture);
	SetShaderMaterial("wood");
	SetShaderAlpha(1.0f);

	m_basicMeshes->DrawBoxMesh();


	// --------------------------------------------------
	// Spellbook - top leather cover
	// --------------------------------------------------
	scaleXYZ = glm::vec3(1.8f, 0.04f, 1.2f);
	positionXYZ = glm::vec3(0.0f, 0.28f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Brown leather cover.
	SetShaderColor(0.35f, 0.08f, 0.10f, 1.0f);
	SetShaderTexture(leatherTexture);
	SetShaderMaterial("wood");
	SetShaderAlpha(1.0f);

	m_basicMeshes->DrawBoxMesh();

	// --------------------------------------------------
	// Spellbook - decorative top cover surface
	// --------------------------------------------------
	scaleXYZ = glm::vec3(0.9f, 1.0f, 0.6f);
	positionXYZ = glm::vec3(0.0f, 0.301f, 0.0f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture(coverTexture);
	SetShaderMaterial("wood");
	SetShaderAlpha(1.0f);

	m_basicMeshes->DrawPlaneMesh();

	// --------------------------------------------------
	// Spellbook - rounded leather spine
	// --------------------------------------------------
	scaleXYZ = glm::vec3(0.30f, 0.30f, 1.80f);
	positionXYZ = glm::vec3(0.0f, 0.15f, -0.60f);

	// Our custom mesh already runs along the Z-axis.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 270.0f;
	ZrotationDegrees = 0.0f;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Brown leather spine.
	SetShaderColor(0.35f, 0.08f, 0.10f, 1.0f);
	SetShaderMaterial("wood");
	SetShaderAlpha(1.0f);

	DrawBookSpineMesh(leatherTexture, spineTexture);

	// Reset rotation so other objects aren't affected.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// --------------------------------------------------
	// Spellbook - cream-colored pages
	// --------------------------------------------------
	scaleXYZ = glm::vec3(1.75f, 0.22f, 1.15f);
	positionXYZ = glm::vec3(0.0f, 0.15f, -0.025f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Aged parchment color.
	SetShaderColor(0.85f, 0.78f, 0.60f, 1.0f);
	SetShaderTexture("pages");
	SetShaderMaterial("wood");
	SetShaderAlpha(1.0f);

	m_basicMeshes->DrawBoxMesh();

	// Disable the shared book transformation
	m_useBookTransform = false;
}


/***********************************************************
 * CreateRockBaseMesh()
 *
 * Creates the custom rocky base mesh that supports
 * the crystal cluster in the Alchemy Table scene.
 ***********************************************************/
void SceneManager::CreateRockBaseMesh()
{
	const int sides = 12;
	const float PI = 3.14159265359f;

	std::vector<float> vertices;

	// Irregular distances from the center
	float radii[sides] = {
		1.0f, 0.85f, 1.12f, 0.90f,
		1.08f, 0.82f, 1.15f, 0.88f,
		1.05f, 0.92f, 1.10f, 0.86f
	};

	// Different heights create an uneven rocky surface
	float heights[sides] = {
		0.25f, 0.42f, 0.30f, 0.55f,
		0.35f, 0.48f, 0.28f, 0.52f,
		0.32f, 0.46f, 0.38f, 0.50f
	};

	auto addVertex = [&](glm::vec3 p, glm::vec3 n,
		float u, float v)
		{
			vertices.push_back(p.x);
			vertices.push_back(p.y);
			vertices.push_back(p.z);

			vertices.push_back(n.x);
			vertices.push_back(n.y);
			vertices.push_back(n.z);

			vertices.push_back(u);
			vertices.push_back(v);
		};

	glm::vec3 centerTop(0.0f, 0.65f, 0.0f);
	glm::vec3 centerBottom(0.0f, -0.15f, 0.0f);

	for (int i = 0; i < sides; i++)
	{
		int next = (i + 1) % sides;

		float angle1 = 2.0f * PI * i / sides;
		float angle2 = 2.0f * PI * next / sides;

		glm::vec3 top1(
			cos(angle1) * radii[i],
			heights[i],
			sin(angle1) * radii[i]
		);

		glm::vec3 top2(
			cos(angle2) * radii[next],
			heights[next],
			sin(angle2) * radii[next]
		);

		glm::vec3 bottom1(top1.x, -0.15f, top1.z);
		glm::vec3 bottom2(top2.x, -0.15f, top2.z);

		// Uneven triangular top surface
		glm::vec3 topNormal = glm::normalize(
			glm::cross(top2 - centerTop, top1 - centerTop)
		);

		addVertex(centerTop, topNormal, 0.5f, 0.5f);
		addVertex(top2, topNormal, 1.0f, 1.0f);
		addVertex(top1, topNormal, 0.0f, 1.0f);

		// Jagged outer side, first triangle
		glm::vec3 sideNormal = glm::normalize(
			glm::cross(top1 - bottom1, bottom2 - bottom1)
		);

		addVertex(bottom1, sideNormal, 0.0f, 0.0f);
		addVertex(top1, sideNormal, 0.0f, 1.0f);
		addVertex(bottom2, sideNormal, 1.0f, 0.0f);

		// Jagged outer side, second triangle
		addVertex(bottom2, sideNormal, 1.0f, 0.0f);
		addVertex(top1, sideNormal, 0.0f, 1.0f);
		addVertex(top2, sideNormal, 1.0f, 1.0f);

		// Bottom face
		glm::vec3 bottomNormal(0.0f, -1.0f, 0.0f);

		addVertex(centerBottom, bottomNormal, 0.5f, 0.5f);
		addVertex(bottom1, bottomNormal, 0.0f, 0.0f);
		addVertex(bottom2, bottomNormal, 1.0f, 0.0f);
	}

	m_rockBaseVertexCount =
		static_cast<GLsizei>(vertices.size() / 8);

	glGenVertexArrays(1, &m_rockBaseVAO);
	glGenBuffers(1, &m_rockBaseVBO);

	glBindVertexArray(m_rockBaseVAO);
	glBindBuffer(GL_ARRAY_BUFFER, m_rockBaseVBO);

	glBufferData(
		GL_ARRAY_BUFFER,
		vertices.size() * sizeof(float),
		vertices.data(),
		GL_STATIC_DRAW
	);

	const GLsizei stride = 8 * sizeof(float);

	// Position
	glVertexAttribPointer(
		0, 3, GL_FLOAT, GL_FALSE,
		stride, (void*)0
	);
	glEnableVertexAttribArray(0);

	// Normal
	glVertexAttribPointer(
		1, 3, GL_FLOAT, GL_FALSE,
		stride, (void*)(3 * sizeof(float))
	);
	glEnableVertexAttribArray(1);

	// Texture coordinates
	glVertexAttribPointer(
		2, 2, GL_FLOAT, GL_FALSE,
		stride, (void*)(6 * sizeof(float))
	);
	glEnableVertexAttribArray(2);

	glBindVertexArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
}

/***********************************************************
 * CreateChestLidMesh()
 *
 * Creates a rounded, solid lid for the alchemy chest.
 ***********************************************************/
void SceneManager::CreateChestLidMesh()
{
	std::vector<float> vertices;

	const int segments = 24;
	const float halfWidth = 0.5f;
	const float halfDepth = 0.5f;
	const float baseY = 0.0f;
	const float curveHeight = 0.35f;

	const float PI = 3.14159265359f;

	// Adds one vertex with position, normal, and UV.
	auto addVertex = [&](glm::vec3 p, glm::vec3 n, float u, float v)
		{
			vertices.insert(vertices.end(),
				{
					p.x, p.y, p.z,
					n.x, n.y, n.z,
					u, v
				});
		};

	auto addTriangle = [&](glm::vec3 a, glm::vec3 b,
		glm::vec3 c,
		float u1, float v1,
		float u2, float v2,
		float u3, float v3)
		{
			glm::vec3 normal = glm::normalize(
				glm::cross(b - a, c - a)
			);

			addVertex(a, normal, u1, v1);
			addVertex(b, normal, u2, v2);
			addVertex(c, normal, u3, v3);
		};

	// Build the curved top and both rounded end faces.
	for (int i = 0; i < segments; i++)
	{
		float t1 = static_cast<float>(i) / segments;
		float t2 = static_cast<float>(i + 1) / segments;

		float x1 = -halfWidth + t1;
		float x2 = -halfWidth + t2;

		float y1 = baseY + curveHeight * sinf(PI * t1);
		float y2 = baseY + curveHeight * sinf(PI * t2);

		glm::vec3 a(x1, y1, -halfDepth);
		glm::vec3 b(x2, y2, -halfDepth);
		glm::vec3 c(x1, y1, halfDepth);
		glm::vec3 d(x2, y2, halfDepth);

		// Curved upper surface - texture rotated 90 degrees clockwise
		addTriangle(a, c, b, 0, 1 - t1, 1, 1 - t1, 0, 1 - t2);
		addTriangle(b, c, d, 0, 1 - t2, 1, 1 - t1, 1, 1 - t2);

		// Front rounded face
		glm::vec3 frontCenter(0, baseY, halfDepth);

		addTriangle(
			frontCenter, c, d,
			0.5f, 0.0f,
			t1, y1,
			t2, y2
		);

		// Back rounded face
		glm::vec3 backCenter(0, baseY, -halfDepth);

		addTriangle(
			backCenter, b, a,
			0.5f, 0.0f,
			t2, y2,
			t1, y1
		);
	}

	// Flat underside
	glm::vec3 p1(-halfWidth, baseY, -halfDepth);
	glm::vec3 p2(halfWidth, baseY, -halfDepth);
	glm::vec3 p3(-halfWidth, baseY, halfDepth);
	glm::vec3 p4(halfWidth, baseY, halfDepth);

	addTriangle(p1, p2, p3, 0, 0, 1, 0, 0, 1);
	addTriangle(p2, p4, p3, 1, 0, 1, 1, 0, 1);

	m_chestLidVertexCount =
		static_cast<GLsizei>(vertices.size() / 8);

	glGenVertexArrays(1, &m_chestLidVAO);
	glGenBuffers(1, &m_chestLidVBO);

	glBindVertexArray(m_chestLidVAO);
	glBindBuffer(GL_ARRAY_BUFFER, m_chestLidVBO);

	glBufferData(
		GL_ARRAY_BUFFER,
		vertices.size() * sizeof(float),
		vertices.data(),
		GL_STATIC_DRAW
	);

	// Vertex positions
	glVertexAttribPointer(
		0, 3, GL_FLOAT, GL_FALSE,
		8 * sizeof(float), (void*)0
	);
	glEnableVertexAttribArray(0);

	// Vertex normals
	glVertexAttribPointer(
		1, 3, GL_FLOAT, GL_FALSE,
		8 * sizeof(float),
		(void*)(3 * sizeof(float))
	);
	glEnableVertexAttribArray(1);

	// Texture coordinates
	glVertexAttribPointer(
		2, 2, GL_FLOAT, GL_FALSE,
		8 * sizeof(float),
		(void*)(6 * sizeof(float))
	);
	glEnableVertexAttribArray(2);

	glBindVertexArray(0);
}

/***********************************************************
 * DrawChestLidTop()
 *
 * Draws only the curved surface of the lid.
 ***********************************************************/
void SceneManager::DrawChestLidTop()
{
	glBindVertexArray(m_chestLidVAO);

	const int segments = 24;

	for (int i = 0; i < segments; i++)
	{
		glDrawArrays(
			GL_TRIANGLES,
			i * 12,
			6
		);
	}

	glBindVertexArray(0);
}

/***********************************************************
 * DrawChestLidSides()
 *
 * Draws the two rounded ends and underside
 * of the alchemy chest lid.
 ***********************************************************/
void SceneManager::DrawChestLidSides()
{
	glBindVertexArray(m_chestLidVAO);

	const int segments = 24;

	for (int i = 0; i < segments; i++)
	{
		// Front rounded end
		glDrawArrays(GL_TRIANGLES, i * 12 + 6, 3);

		// Back rounded end
		glDrawArrays(GL_TRIANGLES, i * 12 + 9, 3);
	}

	// Flat underside
	glDrawArrays(GL_TRIANGLES, segments * 12, 6);

	glBindVertexArray(0);
}


/***********************************************************
 * DrawRockBaseMesh()
 *
 * Renders the custom jagged rocky base.
 ***********************************************************/
void SceneManager::DrawRockBaseMesh()
{
	// Bind the rocky base vertex array.
	glBindVertexArray(m_rockBaseVAO);

	// Draw the triangular faces of the rock.
	glDrawArrays(
		GL_TRIANGLES,
		0,
		m_rockBaseVertexCount
	);

	// Unbind the vertex array.
	glBindVertexArray(0);
}

void SceneManager::CreateHexCrystalMesh()
{
	// Six-sided crystal with a pointed top.
	const int sides = 6;
	const float radius = 0.5f;
	const float bottomY = -0.5f;
	const float shoulderY = 0.5f;
	const float tipY = 1.0f;

	std::vector<float> vertices;

	// Add one vertex: position, normal, texture coordinates.
	auto addVertex = [&](glm::vec3 p, glm::vec3 n,
		float u, float v)
		{
			vertices.push_back(p.x);
			vertices.push_back(p.y);
			vertices.push_back(p.z);

			vertices.push_back(n.x);
			vertices.push_back(n.y);
			vertices.push_back(n.z);

			vertices.push_back(u);
			vertices.push_back(v);
		};

	for (int i = 0; i < sides; i++)
	{
		float angle1 = glm::radians(i * 60.0f);
		float angle2 = glm::radians((i + 1) * 60.0f);

		glm::vec3 bottom1(radius * cos(angle1), bottomY,
			radius * sin(angle1));

		glm::vec3 bottom2(radius * cos(angle2), bottomY,
			radius * sin(angle2));

		glm::vec3 top1(radius * cos(angle1), shoulderY,
			radius * sin(angle1));

		glm::vec3 top2(radius * cos(angle2), shoulderY,
			radius * sin(angle2));

		glm::vec3 tip(0.0f, tipY, 0.0f);

		// Flat normal for each side of the crystal.
		glm::vec3 sideNormal = glm::normalize(
			glm::cross(top1 - bottom1, bottom2 - bottom1));

		// First triangle of the rectangular side.
		addVertex(bottom1, sideNormal, 0.0f, 0.0f);
		addVertex(top1, sideNormal, 0.0f, 1.0f);
		addVertex(bottom2, sideNormal, 1.0f, 0.0f);

		// Second triangle of the rectangular side.
		addVertex(bottom2, sideNormal, 1.0f, 0.0f);
		addVertex(top1, sideNormal, 0.0f, 1.0f);
		addVertex(top2, sideNormal, 1.0f, 1.0f);

		// Pointed top of the crystal.
		// Calculate the outward-facing normal.
		glm::vec3 tipNormal = glm::normalize(
			glm::cross(tip - top1, top2 - top1));

		addVertex(top1, tipNormal, 0.0f, 0.0f);
		addVertex(tip, tipNormal, 0.5f, 1.0f);
		addVertex(top2, tipNormal, 1.0f, 0.0f);

		// Bottom face, divided into six triangles.
		glm::vec3 bottomCenter(0.0f, bottomY, 0.0f);
		glm::vec3 bottomNormal(0.0f, -1.0f, 0.0f);

		addVertex(bottomCenter, bottomNormal, 0.5f, 0.5f);
		addVertex(bottom2, bottomNormal, 1.0f, 0.0f);
		addVertex(bottom1, bottomNormal, 0.0f, 0.0f);
	}

	m_hexCrystalVertexCount =
		static_cast<GLsizei>(vertices.size() / 8);

	// Create the vertex array and buffer.
	glGenVertexArrays(1, &m_hexCrystalVAO);
	glGenBuffers(1, &m_hexCrystalVBO);

	glBindVertexArray(m_hexCrystalVAO);
	glBindBuffer(GL_ARRAY_BUFFER, m_hexCrystalVBO);

	glBufferData(
		GL_ARRAY_BUFFER,
		vertices.size() * sizeof(float),
		vertices.data(),
		GL_STATIC_DRAW
	);

	// Each vertex contains 8 floats.
	const GLsizei stride = 8 * sizeof(float);

	// Position
	glVertexAttribPointer(
		0, 3, GL_FLOAT, GL_FALSE,
		stride, (void*)0
	);
	glEnableVertexAttribArray(0);

	// Normal
	glVertexAttribPointer(
		1, 3, GL_FLOAT, GL_FALSE,
		stride, (void*)(3 * sizeof(float))
	);
	glEnableVertexAttribArray(1);

	// Texture coordinates
	glVertexAttribPointer(
		2, 2, GL_FLOAT, GL_FALSE,
		stride, (void*)(6 * sizeof(float))
	);
	glEnableVertexAttribArray(2);

	glBindVertexArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
}

/***********************************************************
 * DrawHexCrystalMesh()
 *
 * Renders the custom six-sided crystal mesh.
 ***********************************************************/
void SceneManager::DrawHexCrystalMesh()
{
	// Bind the crystal's vertex array.
	glBindVertexArray(m_hexCrystalVAO);

	// Draw all triangles that make up the crystal.
	glDrawArrays(
		GL_TRIANGLES,
		0,
		m_hexCrystalVertexCount
	);

	// Unbind the vertex array.
	glBindVertexArray(0);

}

void SceneManager::RenderCrystal()
{
	// Declare transformation variables.
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;

	// Offset for moving the entire crystal cluster
	glm::vec3 crystalOffset = glm::vec3(2.0f, 0.0f, 2.0f);

	// ----------------------------------------
	// Jagged rocky base
	// ----------------------------------------
	scaleXYZ = glm::vec3(1.0f, 0.7f, 0.8f);
	positionXYZ = glm::vec3(3.5f, 0.10f, 1.0f) + crystalOffset;

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	// Dark gray rocky appearance
	SetShaderMaterial("wood");
	SetShaderAlpha(1.0f);
	SetShaderColor(0.25f, 0.25f, 0.25f, 1.0f);
	SetShaderTexture("darkRock");

	// Draw our custom jagged rock mesh
	DrawRockBaseMesh();

	// ----------------------------------------
	// Main bright orange crystal
	// ----------------------------------------
	scaleXYZ = glm::vec3(0.55f, 1.4f, 0.55f);
	positionXYZ = glm::vec3(3.5f, 1.0f, 1.0f) + crystalOffset;

	XrotationDegrees = 0.0f;
	YrotationDegrees = 25.0f;
	ZrotationDegrees = 0.0f;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	// Apply the orange quartz texture.
	SetShaderMaterial("glass");
	SetShaderAlpha(1.0f);

	SetTextureUVScale(0.5f, 0.5f);
	SetShaderTexture("orangeQuartz");

	// Draw the textured hexagonal crystal.
	DrawHexCrystalMesh();

	// Smaller red crystal growing outward from the main crystal
	scaleXYZ = glm::vec3(0.32f, 0.85f, 0.32f);

	// Move the base closer to the orange crystal
	positionXYZ = glm::vec3(3.15f, 0.65f, 1.0f) + crystalOffset;

	XrotationDegrees = 0.0f;
	YrotationDegrees = 15.0f;

	// Positive Z rotation makes the tip lean left
	ZrotationDegrees = 25.0f;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	// Apply the red quartz texture.
	SetShaderMaterial("glass");
	SetShaderAlpha(1.0f);
	
	SetTextureUVScale(0.25f, 0.5f);
	SetShaderTexture("redQuartz");

	DrawHexCrystalMesh();

	// Golden-yellow crystal growing outward to the right
	scaleXYZ = glm::vec3(0.38f, 1.05f, 0.38f);

	// Position the base close to the main orange crystal
	positionXYZ = glm::vec3(3.85f, 0.70f, 1.0f) + crystalOffset;

	XrotationDegrees = 0.0f;
	YrotationDegrees = -15.0f;

	// Negative Z rotation makes the tip lean right
	ZrotationDegrees = -25.0f;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	// Apply the golden-yellow quartz texture.
	SetShaderMaterial("glass");
	SetShaderAlpha(1.0f);
	
	SetTextureUVScale(0.25f, 0.5f);
	SetShaderTexture("yellowQuartz");

	// Draw the yellow crystal
	DrawHexCrystalMesh();
}

/***********************************************************
 * RenderAlchemyChest()
 *
 * Renders the alchemist's wooden storage chest,
 * including the textured body and curved lid.
 ***********************************************************/
void SceneManager::RenderAlchemyChest()
{
	glm::vec3 scaleXYZ, positionXYZ;

	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;

	// Move the entire chest using one offset.
	glm::vec3 chestOffset = glm::vec3(5.0f, 0.35f, -3.0f);
	// Rotate the entire chest using one rotation.
	float chestRotation = -30.0f;

	// Wooden chest body
	scaleXYZ = glm::vec3(3.0f, 1.5f, 2.0f);
	positionXYZ = glm::vec3(0.0f, 0.40f, 1.0f) + chestOffset;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		chestRotation,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderMaterial("wood");
	SetShaderAlpha(1.0f);

	// Back of chest
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("chestBack");
	m_basicMeshes->DrawBoxFace(0);

	// Bottom of chest
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("chestWood");
	m_basicMeshes->DrawBoxFace(1);

	// Left side of chest
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("chestSide");
	m_basicMeshes->DrawBoxFace(2);

	// Right side of chest
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("chestSide");
	m_basicMeshes->DrawBoxFace(3);

	// Top of chest
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("chestWood");
	m_basicMeshes->DrawBoxFace(4);

	// Front of chest
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("chestFront");
	m_basicMeshes->DrawBoxFace(5);



	// Rounded wooden chest lid
	scaleXYZ = glm::vec3(2.0f, 1.5f, 3.0f);
	positionXYZ = glm::vec3(0.0f, 1.15f, 1.0f) + chestOffset;

	SetTransformations(
		scaleXYZ,
		0.0f,
		90.0f + chestRotation,
		0.0f,
		positionXYZ
	);

	SetShaderMaterial("wood");
	SetShaderAlpha(1.0f);

	// Curved top of the chest lid
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("chestLid");
	DrawChestLidTop();

	// Rounded ends and underside of the lid
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("chestWood");
	DrawChestLidSides();

}

/***********************************************************
 * RenderScene()
 *
 * Renders the complete Alchemy Table scene, including
 * the table, potion bottle, books, crystals, and chest.
 ***********************************************************/
void SceneManager::RenderScene()
{

	// Render the wooden table.
	RenderTable();

	// Render the potion bottle.
	RenderPotionBottle();

	// Bottom book - Alchemy
	RenderSingleBook(0.0f, "redLeather", "alchemyTitle", "alchemyCover");
	// Middle book - Potions
	RenderSingleBook(0.64f, "purpleLeather", "potionsTitle", "potionsCover");
	// Top book - Herbology
	RenderSingleBook(1.28f, "greenLeather", "herbTitle", "herbologyCover");

	// Render the large spellbook in the center of the table.
	RenderSpellbook();

	// Render multicolor crystal.
	RenderCrystal();

	// Render the alchemist's storage chest.
	RenderAlchemyChest();

}

/***********************************************************
 * DefineObjectMaterials()
 *
 * Defines the material properties used throughout the
 * Alchemy Table scene to control lighting and reflections.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// Wood material for the table, books, and treasure chest.
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.ambientStrength = 1.0f;
	woodMaterial.ambientColor = glm::vec3(0.65f, 0.50f, 0.35f);
	woodMaterial.diffuseColor = glm::vec3(0.9f, 0.75f, 0.6f);
	woodMaterial.specularColor = glm::vec3(0.3f, 0.2f, 0.1f);
	woodMaterial.shininess = 16.0f;
	woodMaterial.tag = "wood";
	m_objectMaterials.push_back(woodMaterial);

	// Glass material for the bottle neck, rim, and base.
	OBJECT_MATERIAL glassMaterial;
	glassMaterial.ambientStrength = 0.3f;
	glassMaterial.ambientColor = glm::vec3(0.65f, 0.80f, 0.90f);
	glassMaterial.diffuseColor = glm::vec3(0.75f, 0.85f, 0.95f);
	glassMaterial.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	glassMaterial.shininess = 96.0f;
	glassMaterial.tag = "glass";
	m_objectMaterials.push_back(glassMaterial);

	// Potion material for the liquid inside the bottle.
	OBJECT_MATERIAL potionMaterial;
	potionMaterial.ambientStrength = 0.4f;
	potionMaterial.ambientColor = glm::vec3(0.15f, 0.35f, 0.65f);
	potionMaterial.diffuseColor = glm::vec3(0.25f, 0.55f, 0.90f);
	potionMaterial.specularColor = glm::vec3(0.8f, 0.9f, 1.0f);
	potionMaterial.shininess = 64.0f;
	potionMaterial.tag = "potion";
	m_objectMaterials.push_back(potionMaterial);

	// Cork material for the bottle stopper.
	OBJECT_MATERIAL corkMaterial;
	corkMaterial.ambientStrength = 0.3f;
	corkMaterial.ambientColor = glm::vec3(0.45f, 0.30f, 0.18f);
	corkMaterial.diffuseColor = glm::vec3(0.60f, 0.42f, 0.25f);
	corkMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	corkMaterial.shininess = 8.0f;
	corkMaterial.tag = "cork";
	m_objectMaterials.push_back(corkMaterial);
}

/***********************************************************
 * SetupSceneLights()
 *
 * Configures the light sources used to illuminate
 * the objects in the Alchemy Table scene.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// Enable lighting for the scene.
	m_pShaderManager->setBoolValue("bUseLighting", true);

	// Main light - neutral white illumination.
	m_pShaderManager->setVec3Value(
		"lightSources[0].position",
		glm::vec3(-3.0f, 6.0f, 4.0f));

	m_pShaderManager->setVec3Value(
		"lightSources[0].ambientColor",
		glm::vec3(0.25f, 0.25f, 0.25f));

	m_pShaderManager->setVec3Value(
		"lightSources[0].diffuseColor",
		glm::vec3(0.85f, 0.85f, 0.85f));

	m_pShaderManager->setVec3Value(
		"lightSources[0].specularColor",
		glm::vec3(1.0f, 1.0f, 1.0f));

	m_pShaderManager->setFloatValue(
		"lightSources[0].focalStrength", 32.0f);

	m_pShaderManager->setFloatValue(
		"lightSources[0].specularIntensity", 0.8f);

	// Second light - soft lavender accent lighting.
	m_pShaderManager->setVec3Value(
		"lightSources[1].position",
		glm::vec3(3.0f, 4.0f, -2.0f));

	m_pShaderManager->setVec3Value(
		"lightSources[1].ambientColor",
		glm::vec3(0.10f, 0.10f, 0.10f));

	m_pShaderManager->setVec3Value(
		"lightSources[1].diffuseColor",
		glm::vec3(0.85f, 0.45f, 1.0f));

	m_pShaderManager->setVec3Value(
		"lightSources[1].specularColor",
		glm::vec3(0.70f, 0.70f, 0.70f));

	m_pShaderManager->setFloatValue(
		"lightSources[1].focalStrength", 32.0f);

	m_pShaderManager->setFloatValue(
		"lightSources[1].specularIntensity", 0.5f);

}
