///////////////////////////////////////////////////////////////////////////////
// viewmanager.cpp
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
// 
//	EDITED BY: David Morelli - SNHU Student
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>    

// declaration of the global variables and defines
namespace
{
	// Variables for window width and height
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;
	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// camera object used for viewing and interacting with
	// the 3D scene
	Camera* g_pCamera = nullptr;

	// these variables are used for mouse movement processing
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// time between current frame and last frame
	float gDeltaTime = 0.0f; 
	float gLastFrame = 0.0f;

	// controls the movement speed of the camera
	float gCameraSpeed = 2.5f;

	// the following variable is false when orthographic projection
	// is off and true when it is on
	bool bOrthographicProjection = false;
}

/***********************************************************
 * ViewManager()
 *
 * Initializes the ViewManager and creates the camera
 * with its default position, direction, and zoom settings
 * for viewing the Alchemy Table scene.
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager *pShaderManager)
{
	// initialize the member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;
	g_pCamera = new Camera();
	// default camera view parameters
	g_pCamera->Position = glm::vec3(0.0f, 3.0f, 6.0f);
	g_pCamera->Front = glm::normalize(glm::vec3(0.0f, -0.25f, -1.0f));
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
	g_pCamera->Zoom = 60.0f;
}

/***********************************************************
 * ~ViewManager()
 *
 * Cleans up the ViewManager by releasing the camera
 * memory and resetting the associated pointers.
 ***********************************************************/
ViewManager::~ViewManager()
{
	// free up allocated memory
	m_pShaderManager = NULL;
	m_pWindow = NULL;
	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 * CreateDisplayWindow()
 *
 * Creates the main GLFW display window, configures
 * mouse input callbacks, and enables OpenGL blending
 * to support transparent objects in the scene.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// try to create the displayed OpenGL window
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}
	glfwMakeContextCurrent(window);

	// tell GLFW to capture all mouse events
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// this callback is used to receive mouse moving events
	glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);

	// this callback is used to receive mouse scroll events
	glfwSetScrollCallback(window, &ViewManager::Mouse_Scroll_Callback);

	// enable blending for supporting transparent rendering
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	return(window);
}

/***********************************************************
 * Mouse_Position_Callback()
 *
 * Called by GLFW when the mouse moves within the window.
 * Calculates the mouse movement offsets and updates
 * the camera's viewing direction.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
	// check if this is the first mouse movement
	if (gFirstMouse)
	{
		gLastX = (float)xMousePos;
		gLastY = (float)yMousePos;
		gFirstMouse = false;
	}

	// calculate the mouse movement offset
	float xOffset = (float)xMousePos - gLastX;
	float yOffset = gLastY - (float)yMousePos;

	// save the current mouse position for the next frame
	gLastX = (float)xMousePos;
	gLastY = (float)yMousePos;

	// update the camera orientation based on mouse movement
	g_pCamera->ProcessMouseMovement(xOffset, yOffset);
}

/***********************************************************
* Mouse_Scroll_Callback()
*
* Called by GLFW when the mouse scroll wheel moves.
* Adjusts the camera movement speed while keeping
* it between the minimum and maximum allowed values.
***********************************************************/
void ViewManager::Mouse_Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset)
{
	// increase or decrease the camera movement speed
	gCameraSpeed += (float)yOffset * 0.5f;

	// keep the camera speed within a reasonable range
	if (gCameraSpeed < 0.5f)
	{
		gCameraSpeed = 0.5f;
	}
	if (gCameraSpeed > 10.0f)
	{
		gCameraSpeed = 10.0f;
	}
}

/***********************************************************
 * ProcessKeyboardEvents()
 *
 * Processes keyboard input to control camera movement,
 * switch between perspective and orthographic views,
 * and close the application when Escape is pressed.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	// update the camera movement speed
	g_pCamera->MovementSpeed = gCameraSpeed;
	
	// close the window if the escape key has been pressed
	if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(m_pWindow, true);
	}

	// control the forward and backward movement of the camera
	if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
	}

	// control the left and right movement of the camera
	if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);
	}

	// control the upward and downward movement of the camera
	if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
	{
		g_pCamera->Position += g_pCamera->Up * gDeltaTime * gCameraSpeed;
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
	{
		g_pCamera->Position -= g_pCamera->Up * gDeltaTime * gCameraSpeed;
	}

	// switch to perspective projection
	if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS)
	{
		bOrthographicProjection = false;
	}

	// switch to orthographic projection and reset the camera to a straight-on view of the scene.
	if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS)
	{
		if (!bOrthographicProjection)
		{
			bOrthographicProjection = true;

			// position the camera directly in front of the object
			g_pCamera->Position = glm::vec3(0.0f, 1.2f, 6.0f);
			g_pCamera->Front = glm::vec3(0.0f, 0.0f, -1.0f);
			g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
		}
	}
}

/***********************************************************
 * PrepareSceneView()
 *
 * Updates the camera view and projection settings,
 * processes keyboard input, and sends the camera
 * information to the shader for rendering.
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// per-frame timing
	float currentFrame = glfwGetTime();
	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	// process any keyboard events that may be waiting in the 
	// event queue
	ProcessKeyboardEvents();

	// get the current view matrix from the camera
	view = g_pCamera->GetViewMatrix();

	// define the current projection matrix
	if (bOrthographicProjection)
	{
		float orthoSize = 3.0f;
		float aspectRatio = (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT;

		projection = glm::ortho(
			-orthoSize * aspectRatio,
			orthoSize * aspectRatio,
			-orthoSize,
			orthoSize,
			0.1f,
			100.0f);
	}
	else
	{
		projection = glm::perspective(
			glm::radians(g_pCamera->Zoom),
			(GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT,
			0.1f,
			100.0f);
	}

	// if the shader manager object is valid
	if (NULL != m_pShaderManager)
	{
		// set the view matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ViewName, view);

		// set the projection matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ProjectionName, projection);

		// set the view position of the camera into the shader for proper rendering
		m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
	}
}